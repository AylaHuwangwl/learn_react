import React, { Component } from 'react'

export class MainProduct extends Component {
  render() {
    return (
      <div>MainProduct</div>
    )
  }
}

export default MainProduct