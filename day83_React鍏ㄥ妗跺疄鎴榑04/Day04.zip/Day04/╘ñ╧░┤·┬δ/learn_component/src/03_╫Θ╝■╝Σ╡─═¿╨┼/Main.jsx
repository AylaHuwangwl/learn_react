import React, { Component } from 'react'
import MainBanner from './MainBanner'
import MainProduct from './MainProduct'

export class Main extends Component {
  render() {
    return (
      <div>
        <MainBanner/>
        <MainProduct/>
      </div>
    )
  }
}

export default Main