import ReactDOM from 'react-dom/client';
// import App from './01_组件的嵌套/App';
// import App from './02_组件的生命周期/App'
// import App from './03_组件间的通信/App'
// import App from './04_组件通信案例/App'
// import App from './06_作用域插槽/App'
// import App from "./07_非父子-Context/App"
// import App from "./09_性能优化一/App"
import App from "./10_受控组件/App"

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);