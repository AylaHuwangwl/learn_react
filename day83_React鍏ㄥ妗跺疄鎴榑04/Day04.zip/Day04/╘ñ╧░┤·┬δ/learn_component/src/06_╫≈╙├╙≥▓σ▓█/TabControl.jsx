import React, { Component } from 'react'
import PropTypes from "prop-types"
import classnames from "classnames"
import "./TabControl.css"

class TabControl extends Component {
  static defaultProps = {
    titles: []
  }

  constructor(props) {
    super()

    this.state = {
      currentIndex: 0
    }
  }

  itemClick(index) {
    this.setState({ currentIndex: index })
  }

  render() {
    const { titles, children } = this.props
    const { currentIndex } = this.state
    
    console.log(this.props)

    return (
      <div className='tab-control'>
        {
          titles.map((item, index) => {
            return (
              <div 
                className={classnames('item', {active: index === currentIndex})} 
                key={item}
                onClick={() => this.itemClick(index)}
              >
                { children(item) }
              </div>
            )
          })
        }
      </div>
    )
  }
}


TabControl.propTypes = {
  titles: PropTypes.array
}

TabControl.defaultProps = {
  titles: []
}

export default TabControl