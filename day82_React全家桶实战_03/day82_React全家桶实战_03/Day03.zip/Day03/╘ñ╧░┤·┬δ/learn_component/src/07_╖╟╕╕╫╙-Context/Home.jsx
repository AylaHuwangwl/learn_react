import React, { Component } from 'react'
import HomeProduct from "./HomeProduct"

class Home extends Component {
  render() {
    return (
      <div>
        <HomeProduct/>
      </div>
    )
  }
}

export default Home