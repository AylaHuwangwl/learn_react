import React, { Component } from 'react'
import { UserContext } from "./context"
import eventBus from "./event/event_bus"

class HomeProduct extends Component {
  productClick() {
    eventBus.emit("coderwhy", "why", 18)
  }

  render() {
    console.log(this.context)

    return (
      <div>
        <div>HomeProduct</div>
        <button onClick={e => this.productClick()}>product</button>
      </div>
    )
  }
}

HomeProduct.contextType = UserContext

export default HomeProduct