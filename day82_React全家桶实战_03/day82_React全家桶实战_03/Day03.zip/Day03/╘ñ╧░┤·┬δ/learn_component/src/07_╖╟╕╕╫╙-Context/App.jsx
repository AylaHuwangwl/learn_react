import React, { Component } from 'react'
import Home from "./Home"
import Recommend from "./Recommend"
import { UserContext } from "./context"
import eventBus from "./event/event_bus"

class App extends Component {
  constructor() {
    super()

    this.state = {
      name: "aaa"
    }
  }

  componentDidMount() {
    eventBus.on("coderwhy", this.productClick, this)
  }

  componentWillUnmount() {
    eventBus.off("coderwhy", this.productClick)
  }

  productClick(name, age) {
    console.log("productClick", name, age, this);
    this.setState({ name: name })
  }

  render() {
    return (
      <div className='app'>
        <UserContext.Provider value={{name: "coderwhy", level: 100}}>
          <Home/>
          <Recommend/>
        </UserContext.Provider>
        <h2>{this.state.name}</h2>
      </div>
    )
  }













}

export default App