import React, { Component } from 'react'

class App extends Component {
  render() {
    return (
      <div>App</div>
    )
  }
}


// function App() {
//   console.log(this);
//   return (
//     <div>哈哈哈</div>
//   )
// }

export default App