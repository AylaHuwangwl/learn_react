import React, { Component } from 'react'
// import NavBar from "./NavBar"
import NavBar2 from "./NavBar2"
import "./style.css"

class App extends Component {
  render() {
    const leftSlot = <strong>返回</strong>
    const centerSlot = <h2>购物街</h2>
    const rightSlot = <i>更多</i>

    return (
      <div>
        <NavBar2 
          leftSlot={leftSlot} 
          centerSlot={centerSlot} 
          rightSlot={rightSlot}
        />
      </div>
    )
  }
}

export default App