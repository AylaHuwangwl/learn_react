import React, { Component } from 'react'

export class MainProductList extends Component {
  render() {
    return (
      <div>
        <h2>商品列表</h2>
        <ul>
          <li>商品item01</li>
          <li>商品item02</li>
          <li>商品item03</li>
          <li>商品item04</li>
        </ul>
      </div>
    )
  }
}

export default MainProductList