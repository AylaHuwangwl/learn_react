import React, { Component } from 'react'

export class Footer extends Component {
  render() {
    return (
      <div>Footer</div>
    )
  }
}

export default Footer