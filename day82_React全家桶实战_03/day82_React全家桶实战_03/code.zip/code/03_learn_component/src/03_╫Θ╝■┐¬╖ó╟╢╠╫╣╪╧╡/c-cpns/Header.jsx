import React, { Component } from 'react'

export class Header extends Component {
  render() {
    return (
      <div>Header</div>
    )
  }
}

export default Header